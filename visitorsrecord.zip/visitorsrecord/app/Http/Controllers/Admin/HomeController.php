<?php

namespace App\Http\Controllers\Admin;

class HomeController
{
    public function index()
    {
       // return view('home_ar');
        return view('home');
    }
}
