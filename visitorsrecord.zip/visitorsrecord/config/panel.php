<?php

return [
    'date_format'         => 'd/m/Y',
   // 'date_format'         => 'dd/mm/yy',
    'time_format'         => 'H:i:s',
    'primary_language'    => 'ar',
    'available_languages' => [
        'ar' => 'Arabic',
    ],
];
